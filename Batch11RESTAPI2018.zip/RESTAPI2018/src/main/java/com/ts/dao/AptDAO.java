package com.ts.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.rest.dto.Appointment;
import com.rest.dto.Doctor;
import com.ts.db.HibernateTemplate;

public class AptDAO {
	private SessionFactory factory = null;

	public int register(Appointment appointment) {
		return HibernateTemplate.addObject(appointment);

	}
	
	public List<Appointment> getAllApts() {
		Configuration config = new Configuration();
		config.configure("hibernate.cfg.xml");
		SessionFactory factory = config.buildSessionFactory();
		Session session = factory.openSession();
		Query q1 = session.createQuery("from Appointment a");
		List<Appointment> aptList = q1.list();
		session.close();
		return aptList;
	}

	
}
