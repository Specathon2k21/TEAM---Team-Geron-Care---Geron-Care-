package com.rest.dto;

//import java.sql.Date;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@XmlRootElement
@Entity
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "aptId")
@Table(name = "appointment")
public class Appointment {
	@Id
	@GeneratedValue
	private int aptId;
	private String aptPat;
	private String aptContact;
	private String aptAddress;
	
	private Date aptDate;

	public int getAptId() {
		return aptId;
	}

	public void setAptId(int aptId) {
		this.aptId = aptId;
	}

	public String getAptPat() {
		return aptPat;
	}

	public void setAptPat(String aptPat) {
		this.aptPat = aptPat;
	}

	public String getAptContact() {
		return aptContact;
	}

	public void setAptContact(String aptContact) {
		this.aptContact = aptContact;
	}

	public String getAptAddress() {
		return aptAddress;
	}

	public void setAptAddress(String aptAddress) {
		this.aptAddress = aptAddress;
	}

	
	public Date getAptDate() {
		return aptDate;
	}

	public void setAptDate(Date aptDate) {
		this.aptDate = aptDate;
	}

}
